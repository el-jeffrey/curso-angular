import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UtilesService {

  public tituloSubject = new BehaviorSubject<string>("Titulo");
  public titulo$ = this.tituloSubject.asObservable();
  
  constructor() { }
  /**
   * Setea el titulo a agregar
   * @param titulo titulo a agregar en app.component
   */
  asignarTitulo(titulo){
    this.tituloSubject.next(titulo);
  }

}
